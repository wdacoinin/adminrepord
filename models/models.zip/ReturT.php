<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "retur".
 *
 * @property int $retur
 * @property string $noretur
 * @property string $date
 * @property int $user
 * @property int $retur_status 0.Selesai replace barang identik. 1.Proses. 2.Selesai Replace barang beda. 3.Selesai diganti uang. 
 *
 * @property DoProduk[] $doProduks
 */
class ReturT extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'retur';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['noretur', 'date', 'user'], 'required'],
            [['date'], 'safe'],
            [['user', 'retur_status'], 'integer'],
            [['noretur'], 'string', 'max' => 255],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'retur' => 'Retur',
            'noretur' => 'Noretur',
            'date' => 'Date',
            'user' => 'User',
            'retur_status' => 'Retur Status',
        ];
    }

    /**
     * Gets query for [[DoProduks]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getDoProduks()
    {
        return $this->hasMany(DoProduk::className(), ['retur' => 'retur']);
    }
}
