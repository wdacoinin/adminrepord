<?php

namespace app\models;

use yii\base\Model;
use yii\data\ActiveDataProvider;
use app\models\AktivaT;

/**
 * Aktiva represents the model behind the search form of `app\models\AktivaT`.
 */
class Aktiva extends AktivaT
{
    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['aktiva', 'status'], 'integer'],
            [['aktiva_nama', 'd_k'], 'safe'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function scenarios()
    {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */
    public function search($params)
    {
        $query = AktivaT::find();

        // add conditions that should always apply here

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
        ]);

        $this->load($params);

        if (!$this->validate()) {
            // uncomment the following line if you do not want to return any records when validation fails
            // $query->where('0=1');
            return $dataProvider;
        }

        // grid filtering conditions
        $query->andFilterWhere([
            'aktiva' => $this->aktiva,
            'status' => $this->status,
        ]);

        $query->andFilterWhere(['like', 'aktiva_nama', $this->aktiva_nama])
            ->andFilterWhere(['like', 'd_k', $this->d_k]);

        return $dataProvider;
    }
}
