<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "user".
 *
 * @property int $id
 * @property string $username
 * @property string $password
 * @property string|null $authKey
 * @property string|null $accessToken
 * @property string $nama
 * @property string|null $phone
 * @property int $divisi
 * @property float $gaji
 * @property string $create_date
 *
 * @property AkunSaldo[] $akunSaldos
 * @property ArmadaDetail[] $armadaDetails
 * @property Armada[] $armadas
 * @property Armada[] $armadas0
 * @property Divisi $divisi0

 * @property GudangStok[] $gudangStoks
 * @property Konsinyasi[] $konsinyasis
 * @property Penjualan[] $penjualans
 */

class User extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'user';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['username', 'password', 'nama', 'divisi'], 'required'],
            [['divisi'], 'integer'],
            [['gaji'], 'number'],
            [['create_date'], 'safe'],
            [['username', 'password', 'authKey', 'accessToken'], 'string', 'max' => 255],
            [['nama'], 'string', 'max' => 150],
            [['phone'], 'string', 'max' => 14],
            [['divisi'], 'exist', 'skipOnError' => true, 'targetClass' => Divisi::className(), 'targetAttribute' => ['divisi' => 'divisi']],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'username' => 'Username',
            'password' => 'Password',
            'authKey' => 'Auth Key',
            'accessToken' => 'Access Token',
            'nama' => 'Nama',
            'phone' => 'Phone',
            'divisi' => 'Divisi',
            'gaji' => 'Gaji',
            'create_date' => 'Create Date',
        ];
    }

    /**
     * Gets query for [[AkunSaldos]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getAkunSaldos()
    {
        return $this->hasMany(AkunSaldo::className(), ['user' => 'id']);
    }

    /**
     * Gets query for [[ArmadaDetails]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getArmadaDetails()
    {
        return $this->hasMany(ArmadaDetail::className(), ['us_drop' => 'id']);
    }

    /**
     * Gets query for [[Armadas]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getArmadas()
    {
        return $this->hasMany(Armada::className(), ['kernet' => 'id']);
    }

    /**
     * Gets query for [[Armadas0]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getArmadas0()
    {
        return $this->hasMany(Armada::className(), ['sopir' => 'id']);
    }

    /**
     * Gets query for [[Divisi0]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getDivisi0()
    {
        return $this->hasOne(Divisi::className(), ['divisi' => 'divisi']);
    }

    /**
     * Gets query for [[Dos]].
     *
     * @return \yii\db\ActiveQuery
     */
    /* public function getDos()
    {
        return $this->hasMany(Do::className(), ['us' => 'id']);
    }
 */
    /**
     * Gets query for [[GudangStoks]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getGudangStoks()
    {
        return $this->hasMany(GudangStok::className(), ['us_update' => 'id']);
    }

    /**
     * Gets query for [[Konsinyasis]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getKonsinyasis()
    {
        return $this->hasMany(Konsinyasi::className(), ['us' => 'id']);
    }

    /**
     * Gets query for [[Penjualans]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getPenjualans()
    {
        return $this->hasMany(Penjualan::className(), ['user' => 'id']);
    }
}
