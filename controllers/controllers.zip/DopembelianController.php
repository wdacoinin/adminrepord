<?php

namespace app\controllers;

use Yii;
use yii\widgets\ActiveForm;
use app\models\Dopembelianv;
use app\models\Dopembelian;
use app\models\DopT;
use app\models\DoProduk;
use app\models\DoProdukT;
use app\models\ProdukT;
use app\models\AkunSaldo;
use app\models\AkunSaldoDo;
use app\models\AkunSaldoT;
use app\models\DoProdukOnNota;
use PHPUnit\Framework\Constraint\ExceptionMessage;
use yii\db\Exception;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;

/**
 * DopembelianController implements the CRUD actions for Dopembelianv model.
 */
class DopembelianController extends Controller
{
    /**
     * @inheritDoc
     */
    public function behaviors()
    {
        return array_merge(
            parent::behaviors(),
            [
                'verbs' => [
                    'class' => VerbFilter::className(),
                    'actions' => [
                        'delete' => ['POST'],
                    ],
                ],
            ]
        );
    }

    /**
     * Lists all Dopembelianv models.
     *
     * @return string
     */
    public function actionIndex()
    {
        $this->layout = 'kosong';
        $searchModel = new Dopembelian();
        $dataProvider = $searchModel->search($this->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }

    /**
     * Displays a single Dopembelianv model.
     * @param int $do Do
     * @return string
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionView($do)
    {
        $this->layout = 'kosong';
        return $this->render('view', [
            'model' => $this->findModel($do),
        ]);
    }

    /**
     * Creates a new Dopembelianv model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return string|\yii\web\Response
     */
    public function actionCreate()
    {
        $this->layout = 'kosong';
        $model = new Dopembelianv();

        //validation
        if ($model->load(Yii::$app->request->post())) {
            if (Yii::$app->request->isAjax) {
                Yii::$app->response->format = \yii\web\Response::FORMAT_JSON;
                return ActiveForm::validate($model);
            }
            
            $check = Dopembelianv::find()->where(['nama' => $model->divisi])->count();
            if($check > 0){
                Yii::$app->session->setFlash('warning', 'Nama sudah ada, data tidak di simpan!');
            }else{

                if($model->save()) {
                    Yii::$app->session->setFlash('success', 'Data berhasil di simpan!');
                } else {
                    Yii::$app->session->setFlash('error', 'Data tidak berhasil di simpan');
                }
            }
            return $this->redirect(['index']);
        } else {
            return $this->renderAjax('create', [
                'model' => $model,
            ]);
        }
    }

    /**
     * Updates an existing DopT model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param int $do Do
     * @return string|\yii\web\Response
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionUpdate($do)
    {
        $this->layout = 'kosong';
        $model = $this->findModel($do);
        $modTotal = Dopembelianv::findOne($do);
        $searchModel2 = new DoProdukOnNota();
        $dataProvider2 = $searchModel2->search($this->request->queryParams, $do);
        $searchModel3 = new AkunSaldoDo();
        $dataProvider3 = $searchModel3->search($this->request->queryParams, 12, $do);

        //validation
        if ($model->load(Yii::$app->request->post())) {
            if (Yii::$app->request->isAjax) {
                Yii::$app->response->format = \yii\web\Response::FORMAT_JSON;
                return ActiveForm::validate($model);
            }
            
            if($model->save()) {
                Yii::$app->session->setFlash('success', 'Data berhasil update!');
            } else {
                Yii::$app->session->setFlash('error', 'Data tidak berhasil di update');
            }
            return $this->redirect(['dopembelian/index']);
        } else {
            return $this->render('update', [
                'model' => $model,
                'modTotal' => $modTotal,
                'searchModel2' => $searchModel2,
                'dataProvider2' => $dataProvider2,
                'searchModel3' => $searchModel3,
                'dataProvider3' => $dataProvider3,
            ]);
        }
    }

    public function actionSmerek()
    {
        Yii::$app->response->format = \yii\web\Response::FORMAT_JSON;
        $this->layout = 'api';
        $prop = $_POST['depdrop_parents'];
        $id =$prop[0];

        //var_dump($day);die;
        $merek = ProdukT::find()->select('produk.merek, merek.nama')
        ->join("LEFT JOIN", "merek", "produk.merek=merek.merek")
        ->where(['kategori' => $id])
        ->groupBy('produk.merek')
        ->asArray()->all();

        $dt=[];
        $selected='';
        if($merek != null){

            $data=[];
            foreach($merek as $row){
                $data[] = array(
                    'id' => $row['merek'],
                    'name' => $row['nama'],
                );
                $selected = $data;
            } 
            $dt = $data;
            
            //return $data;
        }
        return ['output'=> $dt, 'selected'=>$selected];
    }

    public function actionSproduk()
    {
        Yii::$app->response->format = \yii\web\Response::FORMAT_JSON;
        $this->layout = 'api';
        $prop = $_POST['depdrop_parents'];
        $merek =$prop[0];
        if (isset($_POST['depdrop_params']) && !empty($_POST['depdrop_params'])) {
            $params = $_POST['depdrop_params'];
            $kategori = $params[0];
        }

        //var_dump($day);die;
        $produk = ProdukT::find()->select('produk, nama')
        ->where(['kategori' => $kategori, 'merek' => $merek])
        ->asArray()->all();

        $dt=[];
        $selected='';
        if($produk != null){

            $data=[];
            foreach($produk as $row){
                $data[] = array(
                    'id' => $row['produk'],
                    'name' => $row['nama'],
                );
                $selected = $data;
            } 
            $dt = $data;
            
            //return $data;
        }
        return ['output'=> $dt, 'selected'=>$selected];
    }


    /**
     * Creates a new DoProdukT model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return string|\yii\web\Response
     */
    public function actionCreateproduk($do)
    {
        $this->layout = 'kosong';
        $model = new DoProdukT();
        $model->do = $do;
        
        //validation
        if ($model->load(Yii::$app->request->post())) {
            if (Yii::$app->request->isAjax) {
                Yii::$app->response->format = \yii\web\Response::FORMAT_JSON;
                return ActiveForm::validate($model);

            }
            
            if($model->validate()){
                $check = DoProdukT::find()->where(['do' => $do, 'produk' => $model->produk, 'stok_jenis' => $model->stok_jenis])->count();
                if($check > 0){
                    Yii::$app->session->setFlash('warning', 'Nama sudah ada, update di produk tersebut, data tidak di simpan!');
                }else{
                    $model->jml_now = $model->do_jml;
                    if($model->save()) {
                        Yii::$app->session->setFlash('success', 'Data berhasil di simpan!');
                    } else {
                        Yii::$app->session->setFlash('error', 'Data tidak berhasil di simpan');
                    }
                }
            }else{
                Yii::$app->session->setFlash('error', 'Data tidak berhasil di simpan');
            }
            
            return $this->redirect(['update', 'do' => $model->do]);
            //return;
        } else {
            return $this->renderAjax('createproduk', [
                'model' => $model,
            ]);
        }
    }

    /**
     * Updates an existing DoProdukT model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param int $do_produk Do Produk
     * @return string|\yii\web\Response
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionUpdateproduk($do_produk)
    {
        $this->layout = 'kosong';
        /* $model = DoProdukT::find()
        ->where(['do_produk' => $do_produk])
        ->join("LEFT JOIN", "merek", "do_produk.merek=merek.merek")
        ->join("LEFT JOIN", "kategori", "do_produk.kategori=kategori.kategori")
        ->one(); */
        $model = DoProdukT::findOne($do_produk);
        $model->produk0->kategori;
        //validation
        if ($model->load(Yii::$app->request->post())) {
            if (Yii::$app->request->isAjax) {
                Yii::$app->response->format = \yii\web\Response::FORMAT_JSON;
                return ActiveForm::validate($model);
            }
            
            if($model->save()) {
                Yii::$app->session->setFlash('success', 'Data berhasil update!');
            } else {
                Yii::$app->session->setFlash('error', 'Data tidak berhasil di update');
            }
            return $this->redirect(['update', 'do' => $model->do]);
        } else {
            return $this->renderAjax('updateproduk', [
                'model' => $model,
            ]);
        }
    }

    /**
     * Deletes an existing Dopembelianv model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param int $do Do
     * @return \yii\web\Response
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionDeleteproduk($do_produk)
    {
        $model = DoProdukT::findOne($do_produk);
        //$transaction = Yii::$app->db->beginTransaction();
        //try {
            if($model->delete()){
                Yii::$app->session->setFlash('sucess', 'Data berhasil dihapus');
            }else{
                Yii::$app->session->setFlash('warning', 'Data tidak hapus, hapus dulu semua item yang ada di pembelian');
            }
        //} catch (Exception $ex) {
            /* Yii::$app->session->setFlash('warning', 'Data tidak hapus, hapus dulu semua item yang ada di pembelian');
            $transaction->rollback(); */
        //}

        return $this->redirect(['dopembelian/update', 'do' => $model->do]);
        //return $this->redirect(['index']);
    }

    /**
     * Deletes an existing Dopembelianv model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param int $do Do
     * @return \yii\web\Response
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionDelete($id)
    {
        $do = $id;
        $model = $this->findModel($do);
        //$transaction = Yii::$app->db->beginTransaction();
        try {
            if($model->delete()){
                Yii::$app->session->setFlash('sucess', 'Data berhasil dihapus');
            }else{
                Yii::$app->session->setFlash('warning', 'Data tidak hapus, hapus dulu semua item yang ada di pembelian');
            }
        } catch (Exception $ex) {
            //$transaction->rollback();
            Yii::$app->session->setFlash('warning', 'Data tidak hapus, hapus dulu semua item yang ada di pembelian');
            return $this->redirect(['index']);
        }

        return $this->redirect(['index']);
    }

    /**
     * Finds the Dopembelianv model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param int $do Do
     * @return DopT the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($do)
    {
        if (($model = DopT::findOne(['do' => $do])) !== null) {
            return $model;
        }

        throw new NotFoundHttpException('The requested page does not exist.');
    }
}
