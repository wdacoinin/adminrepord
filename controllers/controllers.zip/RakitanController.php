<?php

namespace app\controllers;

use Yii;
use yii\widgets\ActiveForm;
use app\models\RakitanT;
use app\models\Rakitan;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use app\models\UploadForm;
use yii\web\UploadedFile;
use yii\helpers\FileHelper;

/**
 * RakitanController implements the CRUD actions for RakitanT model.
 */
class RakitanController extends Controller
{
    /**
     * @inheritDoc
     */
    public function behaviors()
    {
        return array_merge(
            parent::behaviors(),
            [
                'verbs' => [
                    'class' => VerbFilter::className(),
                    'actions' => [
                        'delete' => ['POST'],
                    ],
                ],
            ]
        );
    }

    /**
     * Lists all RakitanT models.
     *
     * @return string
     */
    public function actionIndex()
    {
        $this->layout = 'kosong';
        $searchModel = new Rakitan();
        $dataProvider = $searchModel->search($this->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }

    /**
     * Displays a single RakitanT model.
     * @param int $rakitan Rakitan
     * @return string
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionView($rakitan)
    {
        $this->layout = 'kosong';
        return $this->render('view', [
            'model' => $this->findModel($rakitan),
        ]);
    }

    /**
     * Creates a new RakitanT model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return string|\yii\web\Response
     */
    public function actionCreate()
    {
        $this->layout = 'kosong';
        $model = new RakitanT();
        $UpForm = new UploadForm();

        //validation
        if ($model->load(Yii::$app->request->post())) {
            if (Yii::$app->request->isAjax) {
                Yii::$app->response->format = \yii\web\Response::FORMAT_JSON;
                return ActiveForm::validate($model);
            }  
            
            if($model->nama_foto == ''){
                //========================================================================//
                //===========================IMAGE HANDLE=================================//
                $UpForm->file = UploadedFile::getInstance($UpForm, 'file');

                if ($UpForm->file && $UpForm->validate()) {  
                    //$bytes = random_bytes(3);
                    $ran = substr(str_shuffle('abcdefghjkmnpqrstuvwxyzABCDEFGHJKMNPQRSTUVWXYZ23456789'),0,3);
                    $upload_dir = Yii::getAlias('@webroot') . '/uploads/rakitan/';
                    //var_dump($upload_dir);die;

                    if (!file_exists($upload_dir)) //Buat folder bername temp
                    //mkdir($upload_dir);
                    FileHelper::createDirectory($upload_dir, $mode = 0775, $recursive = true);

                    //image
                    $img = $UpForm->file;
                    //get filesize
                    $file_size = $UpForm->file->size;
                    $url_database = Yii::$app->request->baseUrl . '/uploads/rakitan/' . $model->rakitan . "-" . $ran . '.' . $UpForm->file->extension;
                    $nama_foto = $model->rakitan . "-" . $ran . '.' . $UpForm->file->extension;

                    //save to directori 'upload/doc_penj/'
                    //file_put_contents($file_to_put, $data);
                    $UpForm->file->saveAs($upload_dir . $nama_foto);
                    //set it to model
                    $model->nama_foto = $nama_foto;
                    $model->type = $UpForm->file->extension;
                    $model->size = $file_size;
                    $model->url = $url_database;
                }
                //========================================================================//
                //===========================IMAGE HANDLE=================================//
            }
            $model->status = 'Ready';
            $model->id_user = Yii::$app->user->identity->id;
            if($model->save()) {          
                Yii::$app->session->setFlash('success', 'Data berhasil di simpan!');
            } else {
                Yii::$app->session->setFlash('error', 'Data tidak berhasil di simpan');
            }
            return $this->redirect(['index']);
        } else {
            return $this->renderAjax('create', [
                'model' => $model,
                'UpForm' => $UpForm,
            ]);
        }
    }

    /**
     * Updates an existing RakitanT model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param int $rakitan Rakitan
     * @return string|\yii\web\Response
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionUpdate($rakitan)
    {
        $this->layout = 'kosong';
        $model = $this->findModel($rakitan);
        //$modProduk = 

        //validation
        if ($model->load(Yii::$app->request->post())) {
            if (Yii::$app->request->isAjax) {
                Yii::$app->response->format = \yii\web\Response::FORMAT_JSON;
                return ActiveForm::validate($model);
            }        
            
            if($model->save()) {
                Yii::$app->session->setFlash('success', 'Data berhasil update!');
            } else {
                Yii::$app->session->setFlash('error', 'Data tidak berhasil di update');
            }
            return $this->redirect(['index']);
        } else {
            return $this->render('update', [
                'model' => $model,
            ]);
        }
    }

    /**
     * Updates an existing RakitanT model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param int $rakitan Rakitan
     * @return string|\yii\web\Response
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionUpdategambar($rakitan)
    {
        $this->layout = 'kosong';
        $model = $this->findModel($rakitan);
        $UpForm = new UploadForm();
        $UpForm->file = $model->url;

        //validation
        if ($model->load(Yii::$app->request->post())) {
            if (Yii::$app->request->isAjax) {
                Yii::$app->response->format = \yii\web\Response::FORMAT_JSON;
                return ActiveForm::validate($model);
            }            
            
            if($model->nama_foto == ''){
                //========================================================================//
                //===========================IMAGE HANDLE=================================//
                $UpForm->file = UploadedFile::getInstance($UpForm, 'file');

                if ($UpForm->file && $UpForm->validate()) {  
                    //$bytes = random_bytes(3);
                    $ran = substr(str_shuffle('abcdefghjkmnpqrstuvwxyzABCDEFGHJKMNPQRSTUVWXYZ23456789'),0,3);
                    $upload_dir = Yii::getAlias('@webroot') . '/uploads/rakitan/';
                    //var_dump($upload_dir);die;

                    if (!file_exists($upload_dir)) //Buat folder bername temp
                    //mkdir($upload_dir);
                    FileHelper::createDirectory($upload_dir, $mode = 0775, $recursive = true);

                    //image
                    $img = $UpForm->file;
                    //get filesize
                    $file_size = $UpForm->file->size;
                    $url_database = Yii::$app->request->baseUrl . '/uploads/rakitan/' . $model->inventori0->kode .'-'.  $model->rakitan . '-' . $ran . '.' . $UpForm->file->extension;
                    $nama_foto = $model->inventori0->kode .'-'.  $model->rakitan . "-" . $ran . '.' . $UpForm->file->extension;

                    //save to directori 'upload/doc_penj/'
                    //file_put_contents($file_to_put, $data);
                    $UpForm->file->saveAs($upload_dir . $nama_foto);
                    //set it to model
                    $model->nama_foto = $nama_foto;
                    $model->type = $UpForm->file->extension;
                    $model->size = $file_size;
                    $model->url = $url_database;
                }
                //========================================================================//
                //===========================IMAGE HANDLE=================================//
            }
            
            if($model->save()) {
                Yii::$app->session->setFlash('success', 'Data berhasil update!');
            } else {
                Yii::$app->session->setFlash('error', 'Data tidak berhasil di update');
            }
            return $this->redirect(['index']);
        } else {
            return $this->renderAjax('updategambar', [
                'model' => $model,
                'UpForm' => $UpForm,
            ]);
        }
    }

    /** $id_img, $penjualan
     * @return mixed 
     */
    public function actionDeletefile()
    {
        $file_key = (int)\Yii::$app->request->post('key');

        echo json_encode($file_key);
        
        $RakitanT = RakitanT::findOne($file_key);

        $exp = explode('/',$RakitanT->url,4);
        
        $upload_dir = Yii::getAlias('@webroot') . '/' . $exp[3];
        
        $RakitanT->nama_foto = '';
        $RakitanT->type = '';
        $RakitanT->size = '';
        $RakitanT->url = '';
        if($RakitanT->save()){
            unlink($upload_dir);
        }
        
    }


    /**
     * Deletes an existing RakitanT model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param int $rakitan Rakitan
     * @return \yii\web\Response
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionDelete($rakitan)
    {
        $this->findModel($rakitan)->delete();

        return $this->redirect(['index']);
    }

    /**
     * Finds the RakitanT model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param int $rakitan Rakitan
     * @return RakitanT the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($rakitan)
    {
        if (($model = RakitanT::findOne(['rakitan' => $rakitan])) !== null) {
            return $model;
        }

        throw new NotFoundHttpException('The requested page does not exist.');
    }
}
