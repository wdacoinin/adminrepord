<?php

/* @var $this yii\web\View */
$this->title = Yii::$app->name .'com';
?>
<!-- <div class="site-index"> -->
<div class="col-md-12" style="position:absolute;text-align:center;top:35vh;color: #0a45a0;">
<h3>Selamat datang di aplikasi Regene</h3>
<p class="lead">Login Untuk menggunakan Aplikasi.</p>
</div>
<!-- particles.js container -->
<div id="particles-js"></div>

<!-- scripts -->
<script src="../assets/js/particles.js"></script>
<script src="../assets/js/apppart.js"></script>

<!-- </div> -->
