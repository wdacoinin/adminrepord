
<?php 

function menu_list($divisi, $divisiName){ 
if( $divisi == 2 || $divisi == 1){
?>
    <li class="sidebar-item">
        <a data-target="#sb1" data-toggle="collapse" class="sidebar-link collapsed bg-light" aria-expanded="false">
            <i class="align-middle" data-feather="tag"></i> <span class="align-middle"> Data Penjualan</span>
        </a>

        <ul id="sb1" class="sidebar-dropdown list-unstyled collapse" data-parent="#sidebar">
            <li class="sidebar-item"><a class="sidebar-link bg-light" href="#" style="border-top: #eaeaea;"> Penjualan</a></li>

            <li class="sidebar-item"><a class="sidebar-link bg-light" href="#" style="border-top: #eaeaea;"> Transaksi Penjualan</a></li>

            <li class="sidebar-item"><a class="sidebar-link bg-light" href="#" style="border-top: #eaeaea;"> Transport Fee</a></li>

        </ul>

        <a data-target="#sb2" data-toggle="collapse" class="sidebar-link collapsed bg-light" aria-expanded="false">
            <i class="align-middle" data-feather="tag"></i> <span class="align-middle"> Data Stok</span>
        </a>

        <ul id="sb2" class="sidebar-dropdown list-unstyled collapse" data-parent="#sidebar">

            <li class="sidebar-item"><a class="sidebar-link bg-light" href="../web/indexphp?r=dopembelian" style="border-top: #eaeaea;"> DO Pembelian</a></li>

            <li class="sidebar-item"><a class="sidebar-link bg-light" href="#" style="border-top: #eaeaea;"> Armada</a></li>

            <li class="sidebar-item"><a class="sidebar-link bg-light" href="#" style="border-top: #eaeaea;"> Stok Gudang</a></li>

            <li class="sidebar-item"><a class="sidebar-link bg-light" href="#" style="border-top: #eaeaea;"> Global Stok</a></li>
        </ul>

        <a data-target="#sb3" data-toggle="collapse" class="sidebar-link collapsed bg-light" aria-expanded="false">
            <i class="align-middle" data-feather="tag"></i> <span class="align-middle"> Kas</span>
        </a>

        <ul id="sb3" class="sidebar-dropdown list-unstyled collapse" data-parent="#sidebar">

            <li class="sidebar-item"><a class="sidebar-link bg-light" href="../web/indexphp?r=akun-saldo" style="border-top: #eaeaea;"> Transaksi</a></li>
            <li class="sidebar-item"><a class="sidebar-link bg-light" href="#" style="border-top: #eaeaea;"> Pengeluaran Kas Kecil</a></li>
            <li class="sidebar-item"><a class="sidebar-link bg-light" href="#" style="border-top: #eaeaea;"> Penambahan / Pengambilan Kas</a></li>
            <li class="sidebar-item"><a class="sidebar-link bg-light" href="#" style="border-top: #eaeaea;"> Report Laba kotor</a></li>
            <li class="sidebar-item"><a class="sidebar-link bg-light" href="#" style="border-top: #eaeaea;"> Neraca</a></li>
        </ul>

        <a data-target="#sb4" data-toggle="collapse" class="sidebar-link collapsed bg-light" aria-expanded="false">
            <i class="align-middle" data-feather="tag"></i> <span class="align-middle"> Kelola Aset</span>
        </a>

        <ul id="sb4" class="sidebar-dropdown list-unstyled collapse" data-parent="#sidebar">
            <li class="sidebar-item"><a class="sidebar-link bg-light" href="#" style="border-top: #eaeaea;"> Aset</a></li>
        </ul>

        <a data-target="#sb5" data-toggle="collapse" class="sidebar-link collapsed bg-light" aria-expanded="false">
            <i class="align-middle" data-feather="git-branch"></i> <span class="align-middle"> Linked Data</span>
        </a>

        <ul id="sb5" class="sidebar-dropdown list-unstyled collapse" data-parent="#sidebar">

            <li class="sidebar-item"><a class="sidebar-link bg-light" href="../web/indexphp?r=konsumen" style="border-top: #eaeaea;"> Konsumen</a></li>

            <li class="sidebar-item"><a class="sidebar-link bg-light" href="../web/indexphp?r=supplier" style="border-top: #eaeaea;"> Supplier</a></li>

            <li class="sidebar-item"><a class="sidebar-link bg-light" href="../web/indexphp?r=produk" style="border-top: #eaeaea;"> Produk</a></li>

            <li class="sidebar-item"><a class="sidebar-link bg-light" href="../web/indexphp?r=kategori" style="border-top: #eaeaea;"> Produk Kategori</a></li>

            <li class="sidebar-item"><a class="sidebar-link bg-light" href="../web/indexphp?r=merek" style="border-top: #eaeaea;"> Merek</a></li>

            <li class="sidebar-item"><a class="sidebar-link bg-light" href="../web/indexphp?r=stok-jenis" style="border-top: #eaeaea;"> Jenis Stok</a></li>

            <li class="sidebar-item"><a class="sidebar-link bg-light" href="../web/indexphp?r=inventori" style="border-top: #eaeaea;"> Inventori</a></li>

            <li class="sidebar-item"><a class="sidebar-link bg-light" href="../web/indexphp?r=rakitan" style="border-top: #eaeaea;"> Rakitan</a></li>

            <!-- <li class="sidebar-item"><a class="sidebar-link bg-light" href="../web/indexphp?r=lokasi" style="border-top: #eaeaea;"> Lokasi</a></li> -->

        </ul>

        <a data-target="#sb6" data-toggle="collapse" class="sidebar-link collapsed bg-light" aria-expanded="false">
            <i class="align-middle" data-feather="database"></i> <span class="align-middle"> Base Data  <?php echo ucfirst($divisiName); ?></span>
        </a>

        <ul id="sb6" class="sidebar-dropdown list-unstyled collapse" data-parent="#sidebar">

            <li class="sidebar-item"><a class="sidebar-link bg-light" href="../web/indexphp?r=aktiva" style="border-top: #eaeaea;"> Akun Aktif</a></li>

            <li class="sidebar-item"><a class="sidebar-link bg-light" href="../web/indexphp?r=beban" style="border-top: #eaeaea;"> Beban</a></li>

            <li class="sidebar-item"><a class="sidebar-link bg-light" href="../web/indexphp?r=beban-jenis" style="border-top: #eaeaea;"> Jenis Beban</a></li>

            <li class="sidebar-item"><a class="sidebar-link bg-light" href="../web/indexphp?r=divisi" style="border-top: #eaeaea;"> Divisi</a></li>

            <li class="sidebar-item"><a class="sidebar-link bg-light" href="../web/indexphp?r=backend-user" style="border-top: #eaeaea;"> Karyawan & User</a></li>

            <li class="sidebar-item"><a class="sidebar-link bg-light" href="../web/indexphp?r=akun" style="border-top: #eaeaea;"> Rekening Bank</a></li>

            <li class="sidebar-item"><a class="sidebar-link bg-light" href="../web/indexphp?r=variable" style="border-top: #eaeaea;"> Regene Setting</a></li>

        </ul>

        <!-- <a data-target="#sb3" data-toggle="collapse" class="sidebar-link collapsed bg-light" aria-expanded="false">
            <i class="align-middle" data-feather="trending-up"></i> <span class="align-middle"> Report</span>
        </a>

        <ul id="sb3" class="sidebar-dropdown list-unstyled collapse" data-parent="#sidebar">

            <li class="sidebar-item"><a class="sidebar-link bg-light" href="#" style="border-top: #eaeaea;"> Rugi / Laba</a></li>

            <li class="sidebar-item"><a class="sidebar-link bg-light" href="#" style="border-top: #eaeaea;"> Global Report</a></li>

        </ul> -->
    </li>
 <?php }elseif( $divisi == 3){ ?>
     <li class="sidebar-item">
         <a data-target="#sb1" data-toggle="collapse" class="sidebar-link collapsed bg-light" aria-expanded="false">
             <i class="align-middle" data-feather="tag"></i> <span class="align-middle"> <?php echo ucfirst($divisiName); ?></span>
         </a>
 
         <ul id="sb1" class="sidebar-dropdown list-unstyled collapse" data-parent="#sidebar">
             <li class="sidebar-item"><a class="sidebar-link bg-light" href="../web/indexphp?r=order" style="border-top: #eaeaea;"> Order</a></li>
 
             <li class="sidebar-item"><a class="sidebar-link bg-light" href="../web/indexphp?r=tracking-order" style="border-top: #eaeaea;"> Tracking Order</a></li>

            <li class="sidebar-item"><a class="sidebar-link bg-light" href="../web/indexphp?r=pembayaran-penjualan" style="border-top: #eaeaea;"> Transaksi Penjualan</a></li>
         </ul>
 
         <a data-target="#sb2" data-toggle="collapse" class="sidebar-link collapsed bg-light" aria-expanded="false">
             <i class="align-middle" data-feather="database"></i> <span class="align-middle"> Base Data  <?php echo ucfirst($divisiName); ?></span>
         </a>
 
         <ul id="sb2" class="sidebar-dropdown list-unstyled collapse" data-parent="#sidebar">
 
             <li class="sidebar-item"><a class="sidebar-link bg-light" href="../web/indexphp?r=konsumen" style="border-top: #eaeaea;"> Konsumen</a></li>

            <li class="sidebar-item"><a class="sidebar-link bg-light" href="../web/indexphp?r=akun" style="border-top: #eaeaea;"> Rekening Bank</a></li>

            <li class="sidebar-item"><a class="sidebar-link bg-light" href="../web/indexphp?r=produk" style="border-top: #eaeaea;"> Produk</a></li>

         </ul>
 
     </li>
 
<?php }elseif( $divisi == 5){ ?>
    <li class="sidebar-item">
        <a data-target="#sb1" data-toggle="collapse" class="sidebar-link collapsed bg-light" aria-expanded="false">
            <i class="align-middle" data-feather="tag"></i> <span class="align-middle"> <?php echo ucfirst($divisiName); ?></span>
        </a>

        <ul id="sb1" class="sidebar-dropdown list-unstyled collapse" data-parent="#sidebar">
            <li class="sidebar-item"><a class="sidebar-link bg-light" href="../web/indexphp?r=order" style="border-top: #eaeaea;"> Order</a></li>

            <li class="sidebar-item"><a class="sidebar-link bg-light" href="../web/indexphp?r=tracking-order" style="border-top: #eaeaea;"> Tracking Order</a></li>
        </ul>

        <a data-target="#sb2" data-toggle="collapse" class="sidebar-link collapsed bg-light" aria-expanded="false">
            <i class="align-middle" data-feather="database"></i> <span class="align-middle"> Base Data  <?php echo ucfirst($divisiName); ?></span>
        </a>

        <ul id="sb2" class="sidebar-dropdown list-unstyled collapse" data-parent="#sidebar">

            <li class="sidebar-item"><a class="sidebar-link bg-light" href="../web/indexphp?r=konsumen" style="border-top: #eaeaea;"> Konsumen</a></li>

        </ul>

    </li>

<?php } else { ?> 
    <li class="sidebar-item">
        <a data-target="#sb1" data-toggle="collapse" class="sidebar-link collapsed bg-light" aria-expanded="false">
            <i class="align-middle" data-feather="tag"></i> <span class="align-middle"> <?php echo ucfirst($divisiName); ?></span>
        </a>

        <ul id="sb1" class="sidebar-dropdown list-unstyled collapse" data-parent="#sidebar">
            <li class="sidebar-item"><a class="sidebar-link bg-light" href="../web/indexphp?r=tracking-order" style="border-top: #eaeaea;"> Tracking Order</a></li>
            <li class="sidebar-item"><a class="sidebar-link bg-light" href="../web/indexphp?r=order" style="border-top: #eaeaea;"> Order</a></li>
        </ul>

        <a data-target="#sb2" data-toggle="collapse" class="sidebar-link collapsed bg-light" aria-expanded="false">
            <i class="align-middle" data-feather="database"></i> <span class="align-middle"> Base Data  <?php echo ucfirst($divisiName); ?></span>
        </a>

        <ul id="sb2" class="sidebar-dropdown list-unstyled collapse" data-parent="#sidebar">

            <li class="sidebar-item"><a class="sidebar-link bg-light" href="../web/indexphp?r=konsumen" style="border-top: #eaeaea;"> Konsumen</a></li>

        </ul>
    </li>
<?php } ?> 

<?php } ?>