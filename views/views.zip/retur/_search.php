<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model app\models\Retur */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="retur-t-search">

    <?php $form = ActiveForm::begin([
        'action' => ['index'],
        'method' => 'get',
    ]); ?>

    <?= $form->field($model, 'retur') ?>

    <?= $form->field($model, 'noretur') ?>

    <?= $form->field($model, 'date') ?>

    <?= $form->field($model, 'user') ?>

    <?= $form->field($model, 'retur_status') ?>

    <div class="form-group">
        <?= Html::submitButton('Search', ['class' => 'btn btn-primary']) ?>
        <?= Html::resetButton('Reset', ['class' => 'btn btn-outline-secondary']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
