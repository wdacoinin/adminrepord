<?php

use yii\helpers\Html;
use yii\helpers\Url;
use yii\grid\ActionColumn;
use yii\grid\GridView;

/* @var $this yii\web\View */
/* @var $searchModel app\models\Retur */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Retur Ts';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="retur-t-index">

    <h1><?= Html::encode($this->title) ?></h1>

    <p>
        <?= Html::a('Create Retur T', ['create'], ['class' => 'btn btn-success']) ?>
    </p>

    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>

    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

            'retur',
            'noretur',
            'date',
            'user',
            'retur_status',
            [
                'class' => ActionColumn::className(),
                'urlCreator' => function ($action, ReturT $model, $key, $index, $column) {
                    return Url::toRoute([$action, 'retur' => $model->retur]);
                 }
            ],
        ],
    ]); ?>


</div>
