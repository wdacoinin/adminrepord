<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use app\models\InventoriT;
use kartik\select2\Select2;
use yii\helpers\ArrayHelper;
use app\models\KategoriT;
use app\models\StokJenisT;
use kartik\widgets\FileInput;
use kartik\depdrop\DepDrop;
use yii\helpers\Url;

/* @var $this yii\web\View */
/* @var $model app\models\RakitanT */
/* @var $form yii\widgets\ActiveForm */
/* $initialPreview = $model->url;
$initialPreviewConfig[] = array(
    'key' => $model->rakitan,
    'url' => 'index.php?r=rakitan/deletefile',
    'caption' => $model->nama_foto,
    'size' => $model->size,
); */

?>


<?php $form = ActiveForm::begin(); ?>
<div class="row">
<div class="col-md-3">

    <?= // Usage with ActiveForm and model
    $form->field($model, 'inventori')->widget(Select2::classname(), [
        'data' => ArrayHelper::map(InventoriT::find()->where('lokasi = 1')->orderBy('kode')->asArray()->all(), 'inventori', 'kode'),
        'options' => ['placeholder' => 'Pilih'],
        'pluginOptions' => [
            'allowClear' => true
        ],
    ]); 
    ?>

</div>
<div class="col-md-3">

<?php
    echo '<label class="control-label">Kategori</label>';
    echo Select2::widget([
        'name' => 'kategori',
        'data' => ArrayHelper::map(KategoriT::find()->orderBy('kategori_nama ASC')->asArray()->all(), 'kategori', 'kategori_nama'),
        'options' => [
            'id' => 'kategori',
            'placeholder' => 'Pilih Kategori ...',
        ],
    ]);
    ?>

    <?php
    echo '<label class="control-label">Merek</label>';
    echo DepDrop::widget([
        'name' => 'merek',
        'options'=>[
            'id' => 'merek',
        ],
        'pluginOptions' => [
            'depends' => ['kategori'],
            //'initialize' => true,
            'initDepends' => ['kategori'],
            //'params' => ['reservasipasient-tglreservasi'],
            //'placeholder'=> $model->IDJadwal,
            'url' => Url::to(['/dopembelian/smerek'])
        ],
    ]);
?>
    </div>
    <div class="col-md-3">

<?php
    echo '<label class="control-label">Produk</label>';
    echo DepDrop::widget([
        'name' => 'produk',
        'options' => ['id' => 'produk'],
        'pluginOptions' => [
            'depends' => ['merek'],
            'initialize' => true,
            'initDepends' => ['merek'],
            'params' => ['kategori'],
            //'placeholder'=> $model->IDJadwal,
            'url' => Url::to(['/dopembelian/sproduk'])
        ],
    ]);
    
    
    echo '<label class="control-label">Ready Dari Stok Toko</label>';
    echo DepDrop::widget([
        'name' => 'do_produk',
        'options' => ['id' => 'do_produk'],
        'pluginOptions' => [
            'depends' => ['produk'],
            'initialize' => true,
            'initDepends' => ['produk'],
            //'params' => ['kategori'],
            //'placeholder'=> $model->IDJadwal,
            'url' => Url::to(['/dopembelian/sproduk'])
        ],
    ]);
    ?>
</div>
</div>
<div class="list-group-item">
        <?= Html::submitButton('Update', ['class' => 'btn btn-success']) ?>
</div>

<?php ActiveForm::end(); ?>