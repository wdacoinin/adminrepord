<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model app\models\PenjualanT */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="penjualan-t-form">

    <?php $form = ActiveForm::begin(); ?>

    <?= $form->field($model, 'penjualan_tgl')->textInput() ?>

    <?= $form->field($model, 'penjualan_tempo')->textInput() ?>

    <?= $form->field($model, 'konsumen')->textInput() ?>

    <?= $form->field($model, 'faktur')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'surat_jalan')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'keterangan')->textarea(['rows' => 6]) ?>

    <?= $form->field($model, 'penjualan_ongkir')->textInput() ?>

    <?= $form->field($model, 'fee')->textInput() ?>

    <?= $form->field($model, 'fee_date')->textInput() ?>

    <?= $form->field($model, 'sales')->textInput() ?>

    <?= $form->field($model, 'penjualan_diskon')->textInput() ?>

    <?= $form->field($model, 'user')->textInput() ?>

    <?= $form->field($model, 'penjualan_status')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'akun')->textInput() ?>

    <?= $form->field($model, 'total_bahan')->textInput() ?>

    <div class="form-group">
        <?= Html::submitButton('Save', ['class' => 'btn btn-success']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
