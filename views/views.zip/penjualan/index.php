<?php

use yii\helpers\Html;
use yii\helpers\Url;
use yii\grid\ActionColumn;
use yii\grid\GridView;

/* @var $this yii\web\View */
/* @var $searchModel app\models\Penjualan */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Penjualan Ts';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="penjualan-t-index">

    <h1><?= Html::encode($this->title) ?></h1>

    <p>
        <?= Html::a('Create Penjualan T', ['create'], ['class' => 'btn btn-success']) ?>
    </p>

    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>

    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

            'penjualan',
            'penjualan_tgl',
            'penjualan_tempo',
            'konsumen',
            'faktur',
            //'surat_jalan',
            //'keterangan:ntext',
            //'penjualan_ongkir',
            //'fee',
            //'fee_date',
            //'sales',
            //'penjualan_diskon',
            //'user',
            //'penjualan_status',
            //'akun',
            //'total_bahan',
            [
                'class' => ActionColumn::className(),
                'urlCreator' => function ($action, PenjualanT $model, $key, $index, $column) {
                    return Url::toRoute([$action, 'penjualan' => $model->penjualan]);
                 }
            ],
        ],
    ]); ?>


</div>
