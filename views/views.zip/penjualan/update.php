<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model app\models\PenjualanT */

$this->title = 'Update Penjualan T: ' . $model->penjualan;
$this->params['breadcrumbs'][] = ['label' => 'Penjualan Ts', 'url' => ['index']];
$this->params['breadcrumbs'][] = ['label' => $model->penjualan, 'url' => ['view', 'penjualan' => $model->penjualan]];
$this->params['breadcrumbs'][] = 'Update';
?>
<div class="penjualan-t-update">

    <h1><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
